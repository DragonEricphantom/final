import choose_v2_2 as choose

visit = [6, 1, 5, 7]

path = choose.path(visit)